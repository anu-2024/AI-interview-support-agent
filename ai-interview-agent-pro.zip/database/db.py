# database functions placeholder
