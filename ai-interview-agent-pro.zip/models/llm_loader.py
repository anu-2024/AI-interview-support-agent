# model loader placeholder
